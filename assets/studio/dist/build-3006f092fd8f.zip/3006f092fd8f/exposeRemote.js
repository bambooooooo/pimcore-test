
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.megstyl_studio = "/studio-build/3006f092fd8f/static/js/remoteEntry.js"

      
    